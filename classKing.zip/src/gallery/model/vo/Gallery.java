package gallery.model.vo;

public class Gallery implements java.io.Serializable{
	private final static long serialVersionUID = 9L;
}
