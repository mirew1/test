package comment.model.dao;

public class CommentDao {

}
