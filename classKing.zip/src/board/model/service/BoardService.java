package board.model.service;

public class BoardService {

}
