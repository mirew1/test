package classes.model.dao;

public class ClassesDao {

}
