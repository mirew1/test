package notice.model.vo;

public class Notice implements java.io.Serializable{
	private final static long serialVersionUID = 7L;
}