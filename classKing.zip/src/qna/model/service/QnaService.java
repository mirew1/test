package qna.model.service;

public class QnaService {

}
