package report.model.dao;

public class ReportDao {

}
