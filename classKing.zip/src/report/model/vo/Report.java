package report.model.vo;

public class Report implements java.io.Serializable{
	private final static long serialVersionUID = 5L;
}
