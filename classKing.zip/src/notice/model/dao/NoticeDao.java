package notice.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import static common.JDBCTemplate.*;

public class NoticeDao {

	
}
