package notice.model.service;

public class NoticeService {

}
