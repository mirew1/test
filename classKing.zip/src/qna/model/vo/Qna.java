package qna.model.vo;

public class Qna implements java.io.Serializable{
	private final static long serialVersionUID = 6L;
}
