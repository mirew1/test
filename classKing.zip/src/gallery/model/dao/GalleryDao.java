package gallery.model.dao;

public class GalleryDao {

}
