package comment.model.service;

public class CommentService {

}
