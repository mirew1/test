package apply.model.vo;

public class Apply implements java.io.Serializable{
	private final static long serialVersionUID = 11L;
}