package board.model.vo;

public class Board implements java.io.Serializable{
	private final static long serialVersionUID = 3L;
	
}