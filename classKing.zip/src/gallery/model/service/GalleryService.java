package gallery.model.service;

public class GalleryService {

}
