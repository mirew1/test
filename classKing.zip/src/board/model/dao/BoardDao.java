package board.model.dao;

public class BoardDao {

}
