package calendar.model.dao;

public class CalendarDao {

}
