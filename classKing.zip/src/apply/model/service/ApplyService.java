package apply.model.service;

public class ApplyService {

}
