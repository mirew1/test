package apply.model.dao;

public class ApplyDao {

}
