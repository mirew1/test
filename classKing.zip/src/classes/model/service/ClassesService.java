package classes.model.service;

public class ClassesService {

}
