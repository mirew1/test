package qna.model.dao;

public class QnaDao {

}
