package comment.model.vo;

public class Comment implements java.io.Serializable{
	private final static long serialVersionUID = 4L;
}
